#!/bin/bash
# Thin entrypoint: runtime lives under scripts/ for maintainability.
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/scripts/precommit_main.sh"
run_precommit_main "${1:-}"
exit $?

# =============================================================
#  Pre-commit Hook Setup Script
#  Hệ điều hành: Ubuntu/Debian
# =============================================================

# Bật set -e để dừng ngay khi có lỗi
# Các chỗ cho phép fail dùng `|| true` hoặc `|| warning "..."` tường minh
set -euo pipefail

# ── Màu sắc ───────────────────────────────────────────────────
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

# ── Version config — chỉ cần sửa ở đây khi cập nhật ─────────
GITLEAKS_VERSION="8.30.0"
SEMGREP_VERSION="1.157.0"
GOSEC_VERSION="v2.22.10"
MOBSFSCAN_VERSION="0.4.5"
# Trivy dùng apt repo nên không hardcode version
PRIMARY_VENV_DIR="venv"
MOBSFSCAN_VENV_DIR="mobsfscan-venv"
MOBSFSCAN_BIN="./${MOBSFSCAN_VENV_DIR}/bin/mobsfscan"

# ── Trivy repo signing key config ────────────────────────────
# Nguồn cài đặt chính thức hiện tại dùng get.trivy.dev.
# Có thể override qua env nếu Aqua rotate signing key trong tương lai.
TRIVY_REPO_BASE_URL="${TRIVY_REPO_BASE_URL:-https://get.trivy.dev/deb}"
TRIVY_ALLOWED_GPG_FINGERPRINTS="${TRIVY_ALLOWED_GPG_FINGERPRINTS:-2E2D3567461632C84BB6CD6FE9D0A3616276FA6C}"

# ── Helper functions ──────────────────────────────────────────
info()    { echo -e "${BLUE}[INFO]${NC} $1"; }
success() { echo -e "${GREEN}[✓]${NC} $1"; }
warning() { echo -e "${YELLOW}[!]${NC} $1"; }
error()   { echo -e "${RED}[✗]${NC} $1"; exit 1; }

# ── Kiểm tra OS ───────────────────────────────────────────────
check_os() {
  if ! command -v apt-get &>/dev/null; then
    error "Script này chỉ hỗ trợ Ubuntu/Debian."
  fi
}

cleanup_legacy_mobsfscan_from_primary_venv() {
  if [ ! -d "$PRIMARY_VENV_DIR" ]; then
    return 0
  fi

  source "${PRIMARY_VENV_DIR}/bin/activate"
  if python -m pip show mobsfscan >/dev/null 2>&1; then
    info "Gỡ MobSFScan khỏi môi trường Python chính để tránh xung đột với Semgrep..."
    pip uninstall -y mobsfscan >/dev/null
    success "Đã gỡ MobSFScan khỏi môi trường Python chính"
  fi
}

install_pip_package_with_fallback() {
  local package_name="$1"
  local preferred_version="$2"
  local resolved_version

  if pip install --quiet "${package_name}==${preferred_version}"; then
    printf '%s\n' "$preferred_version"
    return 0
  fi

  warning "Không tìm thấy ${package_name} ${preferred_version} trên index hiện tại. Đang dò bản khả dụng mới nhất..."
  resolved_version=$(
    python -m pip index versions "$package_name" 2>/dev/null \
      | awk -F': ' '/Available versions: /{print $2; exit}' \
      | tr ',' '\n' \
      | sed 's/^ *//; s/ *$//' \
      | sed '/^$/d' \
      | head -1
  )

  if [ -z "$resolved_version" ]; then
    error "Không thể xác định bản ${package_name} khả dụng từ package index hiện tại."
  fi

  warning "Sẽ dùng ${package_name} ${resolved_version} trên máy này."
  pip install --quiet "${package_name}==${resolved_version}"
  printf '%s\n' "$resolved_version"
}

# =============================================================
#  CÀI ĐẶT CÁC TOOL
# =============================================================

install_precommit() {
  info "Tạo môi trường ảo Python..."
  if [ ! -f "${PRIMARY_VENV_DIR}/bin/activate" ]; then
    if [ -d "$PRIMARY_VENV_DIR" ]; then
      warning "Môi trường ảo hiện tại bị thiếu file activate, sẽ tạo lại..."
      rm -rf "$PRIMARY_VENV_DIR"
    fi
    python3 -m venv "$PRIMARY_VENV_DIR"
    success "Đã tạo môi trường ảo"
  else
    success "Môi trường ảo đã tồn tại"
  fi
  source "${PRIMARY_VENV_DIR}/bin/activate"
  pip install --quiet pre-commit
  success "Đã cài pre-commit: $(pre-commit --version)"
}

install_trivy() {
  info "Kiểm tra Trivy..."
  if command -v trivy &>/dev/null; then
    success "Trivy đã được cài: $(trivy --version | head -1)"
    return 0
  fi

  info "Đang cài Trivy..."
  sudo apt-get install -y wget gnupg

  # Download GPG key
  local GPG_TMP
  GPG_TMP=$(mktemp)
  wget -qO "$GPG_TMP" "${TRIVY_REPO_BASE_URL}/public.key"

  # Verify GPG fingerprint — normalize về uppercase, bỏ khoảng trắng
  # để tránh brittle regex phụ thuộc format GPG version / distro
  info "Đang verify GPG fingerprint..."
  local ACTUAL_FP
  ACTUAL_FP=$(gpg --show-keys --with-fingerprint --with-colons "$GPG_TMP" 2>/dev/null \
    | awk -F: '/^fpr/{print $10}' \
    | head -1 \
    | tr '[:lower:]' '[:upper:]' \
    | tr -d ' ')

  local NORMALIZED_ALLOWED_FPS
  NORMALIZED_ALLOWED_FPS=$(printf '%s\n' "$TRIVY_ALLOWED_GPG_FINGERPRINTS" \
    | tr ', ' '\n' \
    | tr '[:lower:]' '[:upper:]' \
    | sed '/^$/d')

  if ! grep -Fxq "$ACTUAL_FP" <<< "$NORMALIZED_ALLOWED_FPS"; then
    rm -f "$GPG_TMP"
    error "GPG fingerprint không khớp!\n  Allowed : ${TRIVY_ALLOWED_GPG_FINGERPRINTS}\n  Actual  : $ACTUAL_FP\nCó thể bị tấn công MITM hoặc signing key đã rotate. Dừng cài đặt."
  fi
  success "GPG fingerprint hợp lệ"

  # Tiến hành cài
  gpg --dearmor < "$GPG_TMP" | sudo tee /usr/share/keyrings/trivy.gpg > /dev/null
  rm -f "$GPG_TMP"
  echo "deb [signed-by=/usr/share/keyrings/trivy.gpg] ${TRIVY_REPO_BASE_URL} generic main" \
    | sudo tee -a /etc/apt/sources.list.d/trivy.list > /dev/null
  sudo apt-get update -qq && sudo apt-get install -y trivy
  success "Đã cài Trivy: $(trivy --version | head -1)"
}

install_semgrep() {
  info "Kiểm tra Semgrep..."
  source "${PRIMARY_VENV_DIR}/bin/activate"
  if command -v semgrep &>/dev/null; then
    local CURRENT_SEMGREP_VERSION
    if CURRENT_SEMGREP_VERSION="$(semgrep --version 2>/dev/null)"; then
      if [ "$CURRENT_SEMGREP_VERSION" = "$SEMGREP_VERSION" ]; then
        success "Semgrep đã được cài: ${CURRENT_SEMGREP_VERSION}"
        return 0
      fi
      info "Semgrep hiện tại là ${CURRENT_SEMGREP_VERSION}, sẽ cập nhật lên ${SEMGREP_VERSION}..."
    else
      warning "Semgrep hiện có nhưng đang lỗi runtime, sẽ cài lại môi trường Semgrep..."
    fi
  fi

  info "Đang cài Semgrep ${SEMGREP_VERSION}..."
  pip install --quiet --upgrade pip setuptools wheel
  CURRENT_SEMGREP_VERSION="$(install_pip_package_with_fallback semgrep "$SEMGREP_VERSION")"
  CURRENT_SEMGREP_VERSION="$(semgrep --version)"

  if ! grep -q ".local/bin" ~/.profile 2>/dev/null; then
    echo 'if [ -d "$HOME/.local/bin" ] ; then PATH="$PATH:$HOME/.local/bin"; fi' >> ~/.profile
  fi
  export PATH="$PATH:$HOME/.local/bin"
  success "Đã cài Semgrep: ${CURRENT_SEMGREP_VERSION}"
}

# Tách logic download ra riêng — dùng được cho cả install lẫn update
_download_gitleaks() {
  local TARBALL="gitleaks_${GITLEAKS_VERSION}_linux_x64.tar.gz"
  local DOWNLOAD_URL="https://github.com/gitleaks/gitleaks/releases/download/v${GITLEAKS_VERSION}/${TARBALL}"
  local CHECKSUM_FILE="gitleaks_${GITLEAKS_VERSION}_checksums.txt"
  local CHECKSUM_URL="https://github.com/gitleaks/gitleaks/releases/download/v${GITLEAKS_VERSION}/${CHECKSUM_FILE}"
  local TMP_DIR
  TMP_DIR=$(mktemp -d)

  info "Đang tải Gitleaks ${GITLEAKS_VERSION}..."
  curl -sSL "$DOWNLOAD_URL" -o "${TMP_DIR}/${TARBALL}"
  curl -sSL "$CHECKSUM_URL" -o "${TMP_DIR}/${CHECKSUM_FILE}"

  # Verify SHA256
  info "Đang verify SHA256 Gitleaks..."
  local EXPECTED_SHA ACTUAL_SHA
  EXPECTED_SHA=$(awk -v tarball="$TARBALL" '$2 == tarball { print $1; exit }' "${TMP_DIR}/${CHECKSUM_FILE}")
  if [ -z "$EXPECTED_SHA" ]; then
    rm -rf "$TMP_DIR"
    error "Không tìm thấy checksum cho ${TARBALL} trong ${CHECKSUM_FILE}. Dừng cài đặt."
  fi
  ACTUAL_SHA=$(sha256sum "${TMP_DIR}/${TARBALL}" | awk '{print $1}')

  if [ "$ACTUAL_SHA" != "$EXPECTED_SHA" ]; then
    rm -rf "$TMP_DIR"
    error "SHA256 Gitleaks không khớp!\n  Expected: $EXPECTED_SHA\n  Actual  : $ACTUAL_SHA\nFile có thể bị chỉnh sửa. Dừng cài đặt."
  fi
  success "SHA256 hợp lệ"

  tar -xz -C "$TMP_DIR" -f "${TMP_DIR}/${TARBALL}"
  sudo mv "${TMP_DIR}/gitleaks" /usr/local/bin/
  rm -rf "$TMP_DIR"
  success "Đã cài Gitleaks: $(gitleaks version)"
}

install_gitleaks() {
  info "Kiểm tra Gitleaks..."
  if command -v gitleaks &>/dev/null; then
    local CURRENT_GITLEAKS_VERSION
    CURRENT_GITLEAKS_VERSION="$(gitleaks version)"
    if [ "$CURRENT_GITLEAKS_VERSION" = "$GITLEAKS_VERSION" ]; then
      success "Gitleaks đã được cài: ${CURRENT_GITLEAKS_VERSION}"
      return 0
    fi
    info "Gitleaks hiện tại là ${CURRENT_GITLEAKS_VERSION}, sẽ cập nhật lên ${GITLEAKS_VERSION}..."
  fi
  _download_gitleaks
}

install_gosec() {
  info "Kiểm tra Gosec..."
  if command -v gosec &>/dev/null; then
    local CURRENT_GOSEC_VERSION
    CURRENT_GOSEC_VERSION="$(gosec -version 2>/dev/null | awk '{print $2}')"
    if [ "$CURRENT_GOSEC_VERSION" = "$GOSEC_VERSION" ]; then
      success "Gosec đã được cài: ${CURRENT_GOSEC_VERSION}"
      return 0
    fi
    info "Gosec hiện tại là ${CURRENT_GOSEC_VERSION:-unknown}, sẽ cập nhật lên ${GOSEC_VERSION}..."
  fi

  info "Đang cài Gosec..."
  if ! command -v go &>/dev/null; then
    warning "Go chưa được cài — bỏ qua Gosec."
    return 1
  fi

  go install "github.com/securego/gosec/v2/cmd/gosec@${GOSEC_VERSION}"
  if ! grep -q "GOPATH" ~/.bashrc 2>/dev/null; then
    echo 'export PATH=$PATH:$(go env GOPATH)/bin' >> ~/.bashrc
  fi
  export PATH="$PATH:$(go env GOPATH)/bin"
  success "Đã cài Gosec"
  return 0
}

install_mobsfscan() {
  info "Kiểm tra MobSFScan..."
  if [ -x "$MOBSFSCAN_BIN" ]; then
    local CURRENT_MOBSFSCAN_VERSION
    CURRENT_MOBSFSCAN_VERSION="$("$MOBSFSCAN_BIN" --version 2>/dev/null | awk '{print $2}' | tr -d 'v')"
    if [ "$CURRENT_MOBSFSCAN_VERSION" = "$MOBSFSCAN_VERSION" ]; then
      success "MobSFScan đã được cài: ${CURRENT_MOBSFSCAN_VERSION}"
      return 0
    fi
    info "MobSFScan hiện tại là ${CURRENT_MOBSFSCAN_VERSION:-unknown}, sẽ cập nhật lên ${MOBSFSCAN_VERSION}..."
  fi

  info "Đang cài MobSFScan..."
  if [ ! -d "$MOBSFSCAN_VENV_DIR" ]; then
    python3 -m venv "$MOBSFSCAN_VENV_DIR"
  fi
  source "${MOBSFSCAN_VENV_DIR}/bin/activate"
  pip install --quiet --upgrade pip setuptools wheel
  CURRENT_MOBSFSCAN_VERSION="$(install_pip_package_with_fallback mobsfscan "$MOBSFSCAN_VERSION")"
  success "Đã cài MobSFScan"
  return 0
}

# =============================================================
#  TẠO SECURITY SUMMARY SCRIPT
# =============================================================

create_summary_script() {
  info "Tạo security-summary.sh..."

  cat > security-summary.sh << 'SUMMARY_EOF'
#!/bin/bash
# =============================================================
#  Security Scan Summary Hook
# =============================================================

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

TIMESTAMP=$(date '+%Y-%m-%d %H:%M:%S')
COMMITTER=$(git config user.name 2>/dev/null || echo "Unknown")
BRANCH=$(git rev-parse --abbrev-ref HEAD 2>/dev/null || echo "Unknown")
MOBSFSCAN_BIN="./mobsfscan-venv/bin/mobsfscan"

GITLEAKS_STATUS=""
TRIVY_VULN_STATUS=""
TRIVY_IAC_STATUS=""
SEMGREP_STATUS=""
GOSEC_STATUS=""
MOBSF_STATUS=""

FAILED_HOOKS=()
PASSED_COUNT=0
FAILED_COUNT=0
SKIPPED_COUNT=0
OVERALL_EXIT=0

check_installed() { command -v "$1" &>/dev/null; }

# Đếm an toàn — trả về 0 thay vì exit code 1 khi không có match
safe_count() {
  local count
  count=$(grep -c -- "$1" <<< "$2" 2>/dev/null || true)
  printf '%s\n' "${count:-0}"
}

# 1. Gitleaks
if check_installed gitleaks; then
  GITLEAKS_REPORT=$(mktemp)
  if gitleaks detect --source . --no-git --report-format json --report-path "$GITLEAKS_REPORT" >/dev/null 2>&1; then
    GITLEAKS_STATUS="${GREEN}PASSED (0 secrets)${NC}"
    ((PASSED_COUNT++))
  else
    COUNT=$(grep -c '"RuleID"' "$GITLEAKS_REPORT" 2>/dev/null || true)
    COUNT=${COUNT:-?}
    GITLEAKS_STATUS="${RED}FAILED (${COUNT} secrets found)${NC}"
    FAILED_HOOKS+=("Gitleaks Secret Detection: FAILED (${COUNT} secrets found)")
    ((FAILED_COUNT++))
    OVERALL_EXIT=1
  fi
  rm -f "$GITLEAKS_REPORT"
else
  GITLEAKS_STATUS="${YELLOW}SKIPPED (not installed)${NC}"
  ((SKIPPED_COUNT++))
fi

# 2. Trivy Vulnerability
if check_installed trivy; then
  OUTPUT=$(trivy fs --severity CRITICAL,HIGH,MEDIUM,LOW --format json . 2>/dev/null)
  CRIT=$(safe_count '"Severity"[[:space:]]*:[[:space:]]*"CRITICAL"' "$OUTPUT")
  HIGH=$(safe_count '"Severity"[[:space:]]*:[[:space:]]*"HIGH"'     "$OUTPUT")
  MED=$(safe_count  '"Severity"[[:space:]]*:[[:space:]]*"MEDIUM"'   "$OUTPUT")
  LOW=$(safe_count  '"Severity"[[:space:]]*:[[:space:]]*"LOW"'      "$OUTPUT")

  if [ "$CRIT" -gt 0 ] || [ "$HIGH" -gt 0 ]; then
    TRIVY_VULN_STATUS="${RED}FAILED (${CRIT} CRIT, ${HIGH} HIGH, ${MED} MED, ${LOW} LOW)${NC}"
    FAILED_HOOKS+=("Trivy Vulnerability Scan: FAILED (${CRIT} CRIT, ${HIGH} HIGH, ${MED} MED, ${LOW} LOW)")
    ((FAILED_COUNT++))
    OVERALL_EXIT=1
  else
    TRIVY_VULN_STATUS="${GREEN}PASSED (${CRIT} CRIT, ${HIGH} HIGH, ${MED} MED, ${LOW} LOW)${NC}"
    ((PASSED_COUNT++))
  fi
else
  TRIVY_VULN_STATUS="${YELLOW}SKIPPED (not installed)${NC}"
  ((SKIPPED_COUNT++))
fi

# 3. Trivy IaC
if check_installed trivy; then
  OUTPUT=$(trivy fs --scanners misconfig --severity CRITICAL,HIGH,MEDIUM,LOW --format json . 2>/dev/null)
  CRIT=$(safe_count '"Severity"[[:space:]]*:[[:space:]]*"CRITICAL"' "$OUTPUT")
  HIGH=$(safe_count '"Severity"[[:space:]]*:[[:space:]]*"HIGH"'     "$OUTPUT")
  MED=$(safe_count  '"Severity"[[:space:]]*:[[:space:]]*"MEDIUM"'   "$OUTPUT")
  LOW=$(safe_count  '"Severity"[[:space:]]*:[[:space:]]*"LOW"'      "$OUTPUT")

  if [ "$CRIT" -gt 0 ] || [ "$HIGH" -gt 0 ]; then
    TRIVY_IAC_STATUS="${RED}FAILED (${CRIT} CRIT, ${HIGH} HIGH, ${MED} MED, ${LOW} LOW)${NC}"
    FAILED_HOOKS+=("Trivy IaC Scan: FAILED (${CRIT} CRIT, ${HIGH} HIGH, ${MED} MED, ${LOW} LOW)")
    ((FAILED_COUNT++))
    OVERALL_EXIT=1
  else
    TRIVY_IAC_STATUS="${GREEN}PASSED (${CRIT} CRIT, ${HIGH} HIGH, ${MED} MED, ${LOW} LOW)${NC}"
    ((PASSED_COUNT++))
  fi
else
  TRIVY_IAC_STATUS="${YELLOW}SKIPPED (not installed)${NC}"
  ((SKIPPED_COUNT++))
fi

# 4. Semgrep
if check_installed semgrep; then
  OUTPUT=$(semgrep scan --config=auto --json . 2>/dev/null)
  ERRORS=$(safe_count   '"severity":"ERROR"'   "$OUTPUT")
  WARNINGS=$(safe_count '"severity":"WARNING"' "$OUTPUT")
  INFOS=$(safe_count    '"severity":"INFO"'    "$OUTPUT")

  if [ "$ERRORS" -gt 0 ]; then
    SEMGREP_STATUS="${RED}FAILED (${ERRORS} ERROR, ${WARNINGS} WARNING, ${INFOS} INFO)${NC}"
    FAILED_HOOKS+=("Semgrep Security Scan: FAILED (${ERRORS} ERROR, ${WARNINGS} WARNING, ${INFOS} INFO)")
    ((FAILED_COUNT++))
    OVERALL_EXIT=1
  else
    SEMGREP_STATUS="${GREEN}PASSED (${ERRORS} ERROR, ${WARNINGS} WARNING, ${INFOS} INFO)${NC}"
    ((PASSED_COUNT++))
  fi
else
  SEMGREP_STATUS="${YELLOW}SKIPPED (not installed)${NC}"
  ((SKIPPED_COUNT++))
fi

# 5. Gosec
if check_installed gosec; then
  OUTPUT=$(gosec -fmt json ./... 2>/dev/null)
  ISSUES=$(safe_count '"severity"' "$OUTPUT")
  if [ "$ISSUES" -gt 0 ]; then
    GOSEC_STATUS="${RED}FAILED (${ISSUES} issues)${NC}"
    FAILED_HOOKS+=("GoSec Security Scan: FAILED (${ISSUES} issues)")
    ((FAILED_COUNT++))
    OVERALL_EXIT=1
  else
    GOSEC_STATUS="${GREEN}PASSED (0 issues)${NC}"
    ((PASSED_COUNT++))
  fi
else
  GOSEC_STATUS="${YELLOW}SKIPPED (not installed)${NC}"
  ((SKIPPED_COUNT++))
fi

# 6. MobSFScan
if [ -x "$MOBSFSCAN_BIN" ]; then
  OUTPUT=$("$MOBSFSCAN_BIN" --json . 2>/dev/null)
  ISSUES=$(safe_count '"severity"' "$OUTPUT")
  if [ "$ISSUES" -gt 0 ]; then
    MOBSF_STATUS="${RED}FAILED (${ISSUES} issues)${NC}"
    FAILED_HOOKS+=("MobSF Mobile Security Scan: FAILED (${ISSUES} issues)")
    ((FAILED_COUNT++))
    OVERALL_EXIT=1
  else
    MOBSF_STATUS="${GREEN}PASSED (0 issues)${NC}"
    ((PASSED_COUNT++))
  fi
else
  MOBSF_STATUS="${YELLOW}SKIPPED (not installed)${NC}"
  ((SKIPPED_COUNT++))
fi

# ── In kết quả ───────────────────────────────────────────────
WIDTH=65
DIVIDER=$(printf '═%.0s' $(seq 1 $WIDTH))
THIN=$(printf '─%.0s' $(seq 1 $WIDTH))

echo ""
echo -e "${CYAN}${BOLD}${DIVIDER}${NC}"
printf "${CYAN}${BOLD}%*s${NC}\n" $(( (WIDTH + 22) / 2 )) "SECURITY SCAN SUMMARY"
echo -e "${CYAN}${BOLD}${DIVIDER}${NC}"
echo ""
echo -e "  ${BOLD}Thời gian :${NC} ${TIMESTAMP}"
echo -e "  ${BOLD}Developer :${NC} ${COMMITTER}"
echo -e "  ${BOLD}Branch    :${NC} ${BRANCH}"
echo ""
echo -e "  ${THIN}"
echo ""
printf "  %-35s %b\n" "✓ Gitleaks Secret Detection"   "$GITLEAKS_STATUS"
printf "  %-35s %b\n" "✓ Trivy Vulnerability Scan"    "$TRIVY_VULN_STATUS"
printf "  %-35s %b\n" "✓ Trivy IaC Scan"              "$TRIVY_IAC_STATUS"
printf "  %-35s %b\n" "✓ Semgrep Security Scan"       "$SEMGREP_STATUS"
printf "  %-35s %b\n" "○ GoSec Security Scan"         "$GOSEC_STATUS"
printf "  %-35s %b\n" "○ MobSF Mobile Security Scan"  "$MOBSF_STATUS"
echo ""
echo -e "  ${THIN}"
echo ""

if [ "$OVERALL_EXIT" -eq 0 ]; then
  echo -e "  ${GREEN}${BOLD}RESULT: PASSED (${PASSED_COUNT} passed, ${SKIPPED_COUNT} skipped)${NC}"
else
  echo -e "  ${RED}${BOLD}RESULT: FAILED (${FAILED_COUNT} failed, ${PASSED_COUNT} passed, ${SKIPPED_COUNT} skipped)${NC}"
  echo ""
  echo -e "  ${RED}${BOLD}Failed hooks:${NC}"
  for hook in "${FAILED_HOOKS[@]}"; do
    echo -e "  ${RED}- ${hook}${NC}"
  done
  echo ""
  echo -e "  ${THIN}"
  echo ""
fi

echo ""
echo -e "${CYAN}${BOLD}${DIVIDER}${NC}"
echo ""

exit $OVERALL_EXIT
SUMMARY_EOF

  chmod +x security-summary.sh
  success "Đã tạo security-summary.sh"
}

# =============================================================
#  TẠO FILE .pre-commit-config.yaml
# =============================================================

create_config() {
  info "Tạo file .pre-commit-config.yaml..."

  if [ -f ".pre-commit-config.yaml" ]; then
    warning "File .pre-commit-config.yaml đã tồn tại, bỏ qua..."
    return
  fi

  cat > .pre-commit-config.yaml << 'EOF'
repos:
  - repo: local
    hooks:
      - id: summary
        name: Security Scan Summary
        language: system
        entry: bash security-summary.sh
        pass_filenames: false
        always_run: true
EOF

  success "Đã tạo .pre-commit-config.yaml"
}

# =============================================================
#  KHỞI TẠO GIT VÀ CÀI HOOK
# =============================================================

setup_git_hook() {
  info "Kiểm tra Git repository..."
  git config --global --add safe.directory "$(pwd)" 2>/dev/null || true

  if [ ! -d ".git" ]; then
    info "Khởi tạo Git repository..."
    git init
    success "Đã khởi tạo Git repository"
  else
    success "Git repository đã tồn tại"
  fi

  source "${PRIMARY_VENV_DIR}/bin/activate"
  pre-commit install
  success "Đã cài pre-commit hook"
}

# =============================================================
#  TEST — không dùng git add để tránh stage file không mong muốn
# =============================================================

run_test() {
  info "Chạy test toàn bộ tool..."
  source "${PRIMARY_VENV_DIR}/bin/activate"
  pre-commit run --all-files
}

# =============================================================
#  UNINSTALL
# =============================================================

uninstall() {
  echo ""
  echo -e "${YELLOW}${BOLD}Đang gỡ cài đặt pre-commit hook...${NC}"

  if [ -d "$PRIMARY_VENV_DIR" ]; then
    source "${PRIMARY_VENV_DIR}/bin/activate"
    pre-commit uninstall || true
    success "Đã gỡ pre-commit hook khỏi Git"
  fi

  rm -f .pre-commit-config.yaml && success "Đã xóa .pre-commit-config.yaml"
  rm -f security-summary.sh     && success "Đã xóa security-summary.sh"
  rm -rf "$MOBSFSCAN_VENV_DIR"  && success "Đã xóa môi trường MobSFScan riêng"

  echo ""
  echo -e "${GREEN}Gỡ cài đặt hoàn tất!${NC}"
  echo -e "Các tool (trivy, semgrep, gitleaks...) vẫn còn trên máy."
  echo -e "Xóa thủ công nếu cần."
  echo ""
  exit 0
}

# =============================================================
#  UPDATE — cập nhật tất cả tool lên version mới nhất
# =============================================================

update() {
  echo ""
  echo -e "${BLUE}${BOLD}Đang cập nhật các tool...${NC}"
  echo ""

  # Cập nhật pre-commit hooks
  if [ -d "$PRIMARY_VENV_DIR" ]; then
    source "${PRIMARY_VENV_DIR}/bin/activate"
    info "Cập nhật pre-commit hooks..."
    pre-commit autoupdate
    success "Đã cập nhật pre-commit hooks"
  fi

  # Cập nhật Trivy
  if command -v trivy &>/dev/null; then
    info "Cập nhật Trivy..."
    sudo apt-get update -qq && sudo apt-get install -y trivy
    success "Đã cập nhật Trivy: $(trivy --version | head -1)"
  fi

  # Cập nhật Semgrep
  if [ -d "$PRIMARY_VENV_DIR" ]; then
    info "Cập nhật Semgrep..."
    source "${PRIMARY_VENV_DIR}/bin/activate"
    pip install --quiet --upgrade pip setuptools wheel
    pip install --quiet "semgrep==${SEMGREP_VERSION}"
    success "Đã cập nhật Semgrep: $(semgrep --version)"
  fi

  # Cập nhật Gitleaks — gọi _download_gitleaks trực tiếp, bỏ qua guard check
  if command -v gitleaks &>/dev/null; then
    info "Cập nhật Gitleaks lên ${GITLEAKS_VERSION}..."
    _download_gitleaks
  fi

  # Cập nhật Gosec
  if command -v gosec &>/dev/null && command -v go &>/dev/null; then
    info "Cập nhật Gosec..."
    go install "github.com/securego/gosec/v2/cmd/gosec@${GOSEC_VERSION}"
    success "Đã cập nhật Gosec"
  fi

  # Cập nhật MobSFScan
  if [ -d "$MOBSFSCAN_VENV_DIR" ]; then
    info "Cập nhật MobSFScan..."
    source "${MOBSFSCAN_VENV_DIR}/bin/activate"
    pip install --quiet --upgrade pip setuptools wheel
    pip install --quiet --upgrade "mobsfscan==${MOBSFSCAN_VERSION}"
    success "Đã cập nhật MobSFScan: $(mobsfscan --version | awk '{print $2}' | tr -d 'v')"
  fi

  echo ""
  echo -e "${GREEN}${BOLD}Cập nhật hoàn tất!${NC}"
  echo ""
  exit 0
}

# =============================================================
#  MAIN
# =============================================================

# Xử lý flag --uninstall / --update
case "${1:-}" in
  --uninstall) uninstall ;;
  --update)    update    ;;
esac

main() {
  echo ""
  echo -e "${BLUE}${BOLD}=================================================${NC}"
  echo -e "${BLUE}${BOLD}   Pre-commit Hook Setup                ${NC}"
  echo -e "${BLUE}${BOLD}=================================================${NC}"
  echo ""
  echo -e "  Versions: Gitleaks ${GITLEAKS_VERSION} | Semgrep ${SEMGREP_VERSION}"
  echo ""

  echo "Bạn có muốn cài các tool tùy chọn không?"
  echo ""
  read -r -p "  Cài Gosec (SAST cho Go)? [Y/N]: " install_gosec_opt
  read -r -p "  Cài MobSFScan (SAST cho Mobile Android/iOS)? [Y/N]: " install_mobsfscan_opt
  echo ""

  INSTALL_GOSEC=false
  INSTALL_MOBSFSCAN=false

  check_os
  install_precommit
  cleanup_legacy_mobsfscan_from_primary_venv
  install_trivy
  install_semgrep
  install_gitleaks

  if [[ "$install_gosec_opt" =~ ^[Yy]$ ]]; then
    install_gosec && INSTALL_GOSEC=true || true
  else
    warning "Bỏ qua Gosec"
  fi

  if [[ "$install_mobsfscan_opt" =~ ^[Yy]$ ]]; then
    install_mobsfscan && INSTALL_MOBSFSCAN=true || true
  else
    warning "Bỏ qua MobSFScan"
  fi

  create_summary_script
  create_config
  setup_git_hook
  run_test

  echo ""
  echo -e "${GREEN}${BOLD}=================================================${NC}"
  echo -e "${GREEN}${BOLD}   Cài đặt hoàn tất!                            ${NC}"
  echo -e "${GREEN}${BOLD}=================================================${NC}"
  echo ""
  echo -e "Từ giờ mỗi lần commit, hook sẽ tự động chạy:"
  echo -e "  ${YELLOW}git add .${NC}"
  echo -e "  ${YELLOW}git commit -m 'your message'${NC}"
  echo ""
  echo -e "Các lệnh hữu ích:"
  echo -e "  ${YELLOW}./precommit.sh --update${NC}     Cập nhật tất cả tool"
  echo -e "  ${YELLOW}./precommit.sh --uninstall${NC}  Gỡ cài đặt hook"
  echo ""
  echo -e "  Mỗi lần mở terminal mới, nhớ chạy:"
  echo -e "  ${YELLOW}source ${PRIMARY_VENV_DIR}/bin/activate${NC}"
  echo ""
}

main
