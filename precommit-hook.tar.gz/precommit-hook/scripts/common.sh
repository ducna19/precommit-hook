#!/bin/bash

set -euo pipefail

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

GITLEAKS_VERSION="8.30.0"
SEMGREP_VERSION="1.157.0"
GOSEC_VERSION="v2.22.10"
MOBSFSCAN_VERSION="0.4.5"

PRIMARY_VENV_DIR="venv"
MOBSFSCAN_VENV_DIR="mobsfscan-venv"
MOBSFSCAN_BIN="./${MOBSFSCAN_VENV_DIR}/bin/mobsfscan"
SCAN_SKIP_DIRS=(".git" "venv" "mobsfscan-venv" "node_modules")
SEMGREP_RULESET="${SEMGREP_RULESET:-p/ci}"

TRIVY_REPO_BASE_URL="${TRIVY_REPO_BASE_URL:-https://get.trivy.dev/deb}"
TRIVY_ALLOWED_GPG_FINGERPRINTS="${TRIVY_ALLOWED_GPG_FINGERPRINTS:-2E2D3567461632C84BB6CD6FE9D0A3616276FA6C}"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
SECURITY_SUMMARY_PY="${ROOT_DIR}/scripts/security_summary.py"

info()    { echo -e "${BLUE}[INFO]${NC} $1"; }
success() { echo -e "${GREEN}[✓]${NC} $1"; }
warning() { echo -e "${YELLOW}[!]${NC} $1"; }
error()   { echo -e "${RED}[✗]${NC} $1"; exit 1; }
