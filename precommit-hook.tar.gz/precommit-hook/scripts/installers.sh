#!/bin/bash

source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/common.sh"

check_os() {
  if ! command -v apt-get &>/dev/null; then
    error "Script này chỉ hỗ trợ Ubuntu/Debian."
  fi
}

check_prerequisites() {
  local missing=()

  command -v git >/dev/null 2>&1 || missing+=("git")
  command -v python3 >/dev/null 2>&1 || missing+=("python3")
  command -v curl >/dev/null 2>&1 || missing+=("curl")
  command -v gpg >/dev/null 2>&1 || missing+=("gpg")
  command -v sha256sum >/dev/null 2>&1 || missing+=("sha256sum")
  python3 -m venv --help >/dev/null 2>&1 || missing+=("python3-venv")

  if [ "${#missing[@]}" -gt 0 ]; then
    error "Thiếu dependency cần thiết: ${missing[*]}. Hãy cài trước khi chạy script."
  fi
}

cleanup_legacy_mobsfscan_from_primary_venv() {
  if [ ! -d "$PRIMARY_VENV_DIR" ]; then
    return 0
  fi

  source "${PRIMARY_VENV_DIR}/bin/activate"
  if python -m pip show mobsfscan >/dev/null 2>&1; then
    info "Gỡ MobSFScan khỏi môi trường Python chính để tránh xung đột với Semgrep..."
    pip uninstall -y mobsfscan >/dev/null
    success "Đã gỡ MobSFScan khỏi môi trường Python chính"
  fi
}

install_pip_package_with_fallback() {
  local package_name="$1"
  local preferred_version="$2"
  local resolved_version

  if pip install --quiet "${package_name}==${preferred_version}"; then
    printf '%s\n' "$preferred_version"
    return 0
  fi

  warning "Không tìm thấy ${package_name} ${preferred_version} trên index hiện tại. Đang dò bản khả dụng mới nhất..."
  resolved_version=$(
    python -m pip index versions "$package_name" 2>/dev/null \
      | awk -F': ' '/Available versions: /{print $2; exit}' \
      | tr ',' '\n' \
      | sed 's/^ *//; s/ *$//' \
      | sed '/^$/d' \
      | head -1
  )

  if [ -z "$resolved_version" ]; then
    error "Không thể xác định bản ${package_name} khả dụng từ package index hiện tại."
  fi

  warning "Sẽ dùng ${package_name} ${resolved_version} trên máy này."
  pip install --quiet "${package_name}==${resolved_version}"
  printf '%s\n' "$resolved_version"
}

ensure_virtualenv() {
  local venv_dir="$1"
  local label="$2"

  if [ ! -f "${venv_dir}/bin/activate" ]; then
    if [ -d "$venv_dir" ]; then
      warning "${label} bị thiếu file activate, sẽ tạo lại..."
      rm -rf "$venv_dir"
    fi
    python3 -m venv "$venv_dir"
    success "Đã tạo ${label}"
  else
    success "${label} đã tồn tại"
  fi
}

install_precommit() {
  info "Tạo môi trường ảo Python..."
  ensure_virtualenv "$PRIMARY_VENV_DIR" "môi trường ảo Python"
  source "${PRIMARY_VENV_DIR}/bin/activate"
  pip install --quiet pre-commit
  success "Đã cài pre-commit: $(pre-commit --version)"
}

install_trivy() {
  info "Kiểm tra Trivy..."
  if command -v trivy &>/dev/null; then
    success "Trivy đã được cài: $(trivy --version | head -1)"
    return 0
  fi

  info "Đang cài Trivy..."
  sudo apt-get install -y wget gnupg

  local gpg_tmp
  local actual_fp
  local normalized_allowed_fps
  gpg_tmp="$(mktemp)"
  wget -qO "$gpg_tmp" "${TRIVY_REPO_BASE_URL}/public.key"

  info "Đang verify GPG fingerprint..."
  actual_fp=$(gpg --show-keys --with-fingerprint --with-colons "$gpg_tmp" 2>/dev/null \
    | awk -F: '/^fpr/{print $10}' \
    | head -1 \
    | tr '[:lower:]' '[:upper:]' \
    | tr -d ' ')

  normalized_allowed_fps=$(printf '%s\n' "$TRIVY_ALLOWED_GPG_FINGERPRINTS" \
    | tr ', ' '\n' \
    | tr '[:lower:]' '[:upper:]' \
    | sed '/^$/d')

  if ! grep -Fxq "$actual_fp" <<< "$normalized_allowed_fps"; then
    rm -f "$gpg_tmp"
    error "GPG fingerprint không khớp!\n  Allowed : ${TRIVY_ALLOWED_GPG_FINGERPRINTS}\n  Actual  : $actual_fp\nCó thể bị tấn công MITM hoặc signing key đã rotate. Dừng cài đặt."
  fi
  success "GPG fingerprint hợp lệ"

  gpg --dearmor < "$gpg_tmp" | sudo tee /usr/share/keyrings/trivy.gpg > /dev/null
  rm -f "$gpg_tmp"
  echo "deb [signed-by=/usr/share/keyrings/trivy.gpg] ${TRIVY_REPO_BASE_URL} generic main" \
    | sudo tee -a /etc/apt/sources.list.d/trivy.list > /dev/null
  sudo apt-get update -qq && sudo apt-get install -y trivy
  success "Đã cài Trivy: $(trivy --version | head -1)"
}

install_semgrep() {
  info "Kiểm tra Semgrep..."
  source "${PRIMARY_VENV_DIR}/bin/activate"
  if command -v semgrep &>/dev/null; then
    local current_semgrep_version
    if current_semgrep_version="$(semgrep --version 2>/dev/null)"; then
      if [ "$current_semgrep_version" = "$SEMGREP_VERSION" ]; then
        success "Semgrep đã được cài: ${current_semgrep_version}"
        return 0
      fi
      info "Semgrep hiện tại là ${current_semgrep_version}, sẽ cập nhật lên ${SEMGREP_VERSION}..."
    else
      warning "Semgrep hiện có nhưng đang lỗi runtime, sẽ cài lại môi trường Semgrep..."
    fi
  fi

  info "Đang cài Semgrep ${SEMGREP_VERSION}..."
  pip install --quiet --upgrade pip setuptools wheel
  install_pip_package_with_fallback semgrep "$SEMGREP_VERSION" >/dev/null
  success "Đã cài Semgrep: $(semgrep --version)"
}

_download_gitleaks() {
  local tarball="gitleaks_${GITLEAKS_VERSION}_linux_x64.tar.gz"
  local download_url="https://github.com/gitleaks/gitleaks/releases/download/v${GITLEAKS_VERSION}/${tarball}"
  local checksum_file="gitleaks_${GITLEAKS_VERSION}_checksums.txt"
  local checksum_url="https://github.com/gitleaks/gitleaks/releases/download/v${GITLEAKS_VERSION}/${checksum_file}"
  local tmp_dir
  local expected_sha
  local actual_sha
  tmp_dir="$(mktemp -d)"

  info "Đang tải Gitleaks ${GITLEAKS_VERSION}..."
  curl -sSL "$download_url" -o "${tmp_dir}/${tarball}"
  curl -sSL "$checksum_url" -o "${tmp_dir}/${checksum_file}"

  info "Đang verify SHA256 Gitleaks..."
  expected_sha=$(awk -v tarball="$tarball" '$2 == tarball { print $1; exit }' "${tmp_dir}/${checksum_file}")
  if [ -z "$expected_sha" ]; then
    rm -rf "$tmp_dir"
    error "Không tìm thấy checksum cho ${tarball} trong ${checksum_file}. Dừng cài đặt."
  fi
  actual_sha=$(sha256sum "${tmp_dir}/${tarball}" | awk '{print $1}')

  if [ "$actual_sha" != "$expected_sha" ]; then
    rm -rf "$tmp_dir"
    error "SHA256 Gitleaks không khớp!\n  Expected: $expected_sha\n  Actual  : $actual_sha\nFile có thể bị chỉnh sửa. Dừng cài đặt."
  fi
  success "SHA256 hợp lệ"

  tar -xz -C "$tmp_dir" -f "${tmp_dir}/${tarball}"
  sudo mv "${tmp_dir}/gitleaks" /usr/local/bin/
  rm -rf "$tmp_dir"
  success "Đã cài Gitleaks: $(gitleaks version)"
}

install_gitleaks() {
  info "Kiểm tra Gitleaks..."
  if command -v gitleaks &>/dev/null; then
    local current_gitleaks_version
    current_gitleaks_version="$(gitleaks version)"
    if [ "$current_gitleaks_version" = "$GITLEAKS_VERSION" ]; then
      success "Gitleaks đã được cài: ${current_gitleaks_version}"
      return 0
    fi
    info "Gitleaks hiện tại là ${current_gitleaks_version}, sẽ cập nhật lên ${GITLEAKS_VERSION}..."
  fi
  _download_gitleaks
}

install_gosec() {
  info "Kiểm tra Gosec..."
  if command -v gosec &>/dev/null; then
    local current_gosec_version
    current_gosec_version="$(gosec -version 2>/dev/null | awk '{print $2}')"
    if [ "$current_gosec_version" = "$GOSEC_VERSION" ]; then
      success "Gosec đã được cài: ${current_gosec_version}"
      return 0
    fi
    info "Gosec hiện tại là ${current_gosec_version:-unknown}, sẽ cập nhật lên ${GOSEC_VERSION}..."
  fi

  info "Đang cài Gosec..."
  if ! command -v go &>/dev/null; then
    warning "Go chưa được cài — bỏ qua Gosec."
    return 1
  fi

  go install "github.com/securego/gosec/v2/cmd/gosec@${GOSEC_VERSION}"
  if ! grep -q "GOPATH" ~/.bashrc 2>/dev/null; then
    echo 'export PATH=$PATH:$(go env GOPATH)/bin' >> ~/.bashrc
  fi
  export PATH="$PATH:$(go env GOPATH)/bin"
  success "Đã cài Gosec"
  return 0
}

install_mobsfscan() {
  info "Kiểm tra MobSFScan..."
  if [ -x "$MOBSFSCAN_BIN" ]; then
    local current_mobsfscan_version
    current_mobsfscan_version="$("$MOBSFSCAN_BIN" --version 2>/dev/null | awk '{print $2}' | tr -d 'v')"
    if [ "$current_mobsfscan_version" = "$MOBSFSCAN_VERSION" ]; then
      success "MobSFScan đã được cài: ${current_mobsfscan_version}"
      return 0
    fi
    info "MobSFScan hiện tại là ${current_mobsfscan_version:-unknown}, sẽ cập nhật lên ${MOBSFSCAN_VERSION}..."
  fi

  info "Đang cài MobSFScan..."
  ensure_virtualenv "$MOBSFSCAN_VENV_DIR" "môi trường MobSFScan riêng"
  source "${MOBSFSCAN_VENV_DIR}/bin/activate"
  pip install --quiet --upgrade pip setuptools wheel
  install_pip_package_with_fallback mobsfscan "$MOBSFSCAN_VERSION" >/dev/null
  success "Đã cài MobSFScan: $("${MOBSFSCAN_BIN}" --version 2>/dev/null | awk '{print $2}' | tr -d 'v')"
  return 0
}

