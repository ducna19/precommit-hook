#!/bin/bash

set -euo pipefail

source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/common.sh"
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/installers.sh"

ENABLE_GITLEAKS="true"
ENABLE_SEMGREP="true"
ENABLE_TRIVY="true"
ENABLE_GOSEC="false"
ENABLE_MOBSFSCAN="false"

normalize_choice() {
  case "${1:-}" in
    [Yy]|[Yy][Ee][Ss]|true|TRUE|1) echo "true" ;;
    *) echo "false" ;;
  esac
}

prompt_tool_selection() {
  echo "Bạn có muốn cài các tool nào?"
  echo ""
  read -r -p "  Cài Gitleaks (Secret Scanning)? [Y/N]: " install_gitleaks_opt
  read -r -p "  Cài Semgrep (SAST đa ngôn ngữ)? [Y/N]: " install_semgrep_opt
  read -r -p "  Cài Trivy (Dependency + IaC scan)? [Y/N]: " install_trivy_opt
  read -r -p "  Cài Gosec (SAST cho Go)? [Y/N]: " install_gosec_opt
  read -r -p "  Cài MobSFScan (SAST cho Mobile Android/iOS)? [Y/N]: " install_mobsfscan_opt
  echo ""

  ENABLE_GITLEAKS="$(normalize_choice "$install_gitleaks_opt")"
  ENABLE_SEMGREP="$(normalize_choice "$install_semgrep_opt")"
  ENABLE_TRIVY="$(normalize_choice "$install_trivy_opt")"
  ENABLE_GOSEC="$(normalize_choice "$install_gosec_opt")"
  ENABLE_MOBSFSCAN="$(normalize_choice "$install_mobsfscan_opt")"
}

create_summary_script() {
  info "Tạo security-summary.sh..."
  cat > "${ROOT_DIR}/security-summary.sh" <<EOF
#!/bin/bash
set -euo pipefail
SCRIPT_DIR="\$(cd "\$(dirname "\${BASH_SOURCE[0]}")" && pwd)"
export ENABLE_GITLEAKS="${ENABLE_GITLEAKS}"
export ENABLE_SEMGREP="${ENABLE_SEMGREP}"
export ENABLE_TRIVY="${ENABLE_TRIVY}"
export ENABLE_GOSEC="${ENABLE_GOSEC}"
export ENABLE_MOBSFSCAN="${ENABLE_MOBSFSCAN}"
export SEMGREP_RULESET="${SEMGREP_RULESET}"
python3 "\${SCRIPT_DIR}/scripts/security_summary.py" "\$@"
EOF
  chmod +x "${ROOT_DIR}/security-summary.sh"
  success "Đã tạo security-summary.sh"
}

create_config() {
  info "Tạo file .pre-commit-config.yaml..."
  if [ -f "${ROOT_DIR}/.pre-commit-config.yaml" ]; then
    warning "File .pre-commit-config.yaml đã tồn tại, sẽ ghi đè bằng cấu hình mới..."
  fi

  cat > "${ROOT_DIR}/.pre-commit-config.yaml" << 'EOF'
repos:
  - repo: local
    hooks:
      - id: summary
        name: Security Scan Summary
        language: system
        entry: bash security-summary.sh
        pass_filenames: true
EOF

  success "Đã tạo .pre-commit-config.yaml"
}

setup_git_hook() {
  info "Kiểm tra Git repository..."

  if [ ! -d "${ROOT_DIR}/.git" ]; then
    info "Khởi tạo Git repository..."
    git -C "${ROOT_DIR}" init
    success "Đã khởi tạo Git repository"
  else
    success "Git repository đã tồn tại"
  fi

  source "${ROOT_DIR}/${PRIMARY_VENV_DIR}/bin/activate"
  (cd "${ROOT_DIR}" && pre-commit install)
  success "Đã cài pre-commit hook"
}

uninstall() {
  echo ""
  echo -e "${YELLOW}${BOLD}Đang gỡ cài đặt pre-commit hook...${NC}"

  if [ -d "${ROOT_DIR}/${PRIMARY_VENV_DIR}" ]; then
    source "${ROOT_DIR}/${PRIMARY_VENV_DIR}/bin/activate"
    (cd "${ROOT_DIR}" && pre-commit uninstall) || true
    success "Đã gỡ pre-commit hook khỏi Git"
  fi

  rm -f "${ROOT_DIR}/.pre-commit-config.yaml" && success "Đã xóa .pre-commit-config.yaml"
  rm -f "${ROOT_DIR}/security-summary.sh" && success "Đã xóa security-summary.sh"
  rm -rf "${ROOT_DIR}/${MOBSFSCAN_VENV_DIR}" && success "Đã xóa môi trường MobSFScan riêng"

  echo ""
  echo -e "${GREEN}Gỡ cài đặt hoàn tất!${NC}"
  echo -e "Các tool (trivy, semgrep, gitleaks...) vẫn còn trên máy."
  echo -e "Xóa thủ công nếu cần."
  echo ""
  exit 0
}

update() {
  echo ""
  echo -e "${BLUE}${BOLD}Đang cập nhật các tool...${NC}"
  echo ""

  if [ -d "${ROOT_DIR}/${PRIMARY_VENV_DIR}" ]; then
    source "${ROOT_DIR}/${PRIMARY_VENV_DIR}/bin/activate"
    info "Cập nhật pre-commit hooks..."
    (cd "${ROOT_DIR}" && pre-commit autoupdate)
    success "Đã cập nhật pre-commit hooks"
  fi

  if command -v trivy &>/dev/null; then
    info "Cập nhật Trivy..."
    sudo apt-get update -qq && sudo apt-get install -y trivy
    success "Đã cập nhật Trivy: $(trivy --version | head -1)"
  fi

  if [ -d "${ROOT_DIR}/${PRIMARY_VENV_DIR}" ]; then
    info "Cập nhật Semgrep..."
    source "${ROOT_DIR}/${PRIMARY_VENV_DIR}/bin/activate"
    pip install --quiet --upgrade pip setuptools wheel
    install_pip_package_with_fallback semgrep "$SEMGREP_VERSION" >/dev/null
    success "Đã cập nhật Semgrep: $(semgrep --version)"
  fi

  if command -v gitleaks &>/dev/null; then
    info "Cập nhật Gitleaks lên ${GITLEAKS_VERSION}..."
    _download_gitleaks
  fi

  if command -v gosec &>/dev/null && command -v go &>/dev/null; then
    info "Cập nhật Gosec..."
    go install "github.com/securego/gosec/v2/cmd/gosec@${GOSEC_VERSION}"
    success "Đã cập nhật Gosec"
  fi

  if [ -d "${ROOT_DIR}/${MOBSFSCAN_VENV_DIR}" ]; then
    info "Cập nhật MobSFScan..."
    source "${ROOT_DIR}/${MOBSFSCAN_VENV_DIR}/bin/activate"
    pip install --quiet --upgrade pip setuptools wheel
    install_pip_package_with_fallback mobsfscan "$MOBSFSCAN_VERSION" >/dev/null
    success "Đã cập nhật MobSFScan: $(mobsfscan --version | awk '{print $2}' | tr -d 'v')"
  fi

  echo ""
  echo -e "${GREEN}${BOLD}Cập nhật hoàn tất!${NC}"
  echo ""
  exit 0
}

run_precommit_main() {
  case "${1:-}" in
    --uninstall) uninstall ;;
    --update) update ;;
  esac

  cd "${ROOT_DIR}"

  echo ""
  echo -e "${BLUE}${BOLD}=================================================${NC}"
  echo -e "${BLUE}${BOLD}   Pre-commit Hook Setup Script         ${NC}"
  echo -e "${BLUE}${BOLD}=================================================${NC}"
  echo ""
  echo -e "  Versions: Gitleaks ${GITLEAKS_VERSION} | Semgrep ${SEMGREP_VERSION} | MobSFScan ${MOBSFSCAN_VERSION}"
  echo ""

  prompt_tool_selection

  check_os
  check_prerequisites
  install_precommit
  if [ "$ENABLE_SEMGREP" = "true" ] || [ "$ENABLE_MOBSFSCAN" = "true" ]; then
    cleanup_legacy_mobsfscan_from_primary_venv
  fi

  if [ "$ENABLE_TRIVY" = "true" ]; then
    install_trivy
  else
    warning "Bỏ qua Trivy"
  fi

  if [ "$ENABLE_SEMGREP" = "true" ]; then
    install_semgrep
  else
    warning "Bỏ qua Semgrep"
  fi

  if [ "$ENABLE_GITLEAKS" = "true" ]; then
    install_gitleaks
  else
    warning "Bỏ qua Gitleaks"
  fi

  if [ "$ENABLE_GOSEC" = "true" ]; then
    install_gosec || true
  else
    warning "Bỏ qua Gosec"
  fi

  if [ "$ENABLE_MOBSFSCAN" = "true" ]; then
    install_mobsfscan || true
  else
    warning "Bỏ qua MobSFScan"
  fi

  create_summary_script
  create_config
  setup_git_hook

  echo ""
  echo -e "${GREEN}${BOLD}=================================================${NC}"
  echo -e "${GREEN}${BOLD}   Cài đặt hoàn tất!                            ${NC}"
  echo -e "${GREEN}${BOLD}=================================================${NC}"
  echo ""
  echo -e "Từ giờ mỗi lần commit, hook sẽ tự động chạy:"
  echo -e "  ${YELLOW}git add .${NC}"
  echo -e "  ${YELLOW}git commit -m 'your message'${NC}"
  echo ""
  echo -e "Các lệnh hữu ích:"
  echo -e "  ${YELLOW}./precommit.sh --update${NC}     Cập nhật tất cả tool"
  echo -e "  ${YELLOW}./precommit.sh --uninstall${NC}  Gỡ cài đặt hook"
  echo -e "  ${YELLOW}pre-commit run --all-files${NC}  Chạy test hook thủ công"
  echo ""
  echo -e "⚠️  Mỗi lần mở terminal mới, nhớ chạy:"
  echo -e "  ${YELLOW}source ${PRIMARY_VENV_DIR}/bin/activate${NC}"
  echo ""
}
