#!/usr/bin/env python3
import json
import os
import shutil
import subprocess
import sys
import tempfile
from collections import Counter
from datetime import datetime
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parent.parent
PRIMARY_VENV_BIN_DIR = ROOT_DIR / "venv" / "bin"
SEMGREP_BIN = PRIMARY_VENV_BIN_DIR / "semgrep"
MOBSFSCAN_BIN = ROOT_DIR / "mobsfscan-venv" / "bin" / "mobsfscan"
SCAN_SKIP_DIRS = [".git", "venv", "mobsfscan-venv", "node_modules"]
SEMGREP_RULESET = os.environ.get("SEMGREP_RULESET", "p/ci")
ENABLE_GITLEAKS = os.environ.get("ENABLE_GITLEAKS", "true").lower() == "true"
ENABLE_SEMGREP = os.environ.get("ENABLE_SEMGREP", "true").lower() == "true"
ENABLE_TRIVY = os.environ.get("ENABLE_TRIVY", "true").lower() == "true"
ENABLE_GOSEC = os.environ.get("ENABLE_GOSEC", "false").lower() == "true"
ENABLE_MOBSFSCAN = os.environ.get("ENABLE_MOBSFSCAN", "false").lower() == "true"
SHOW_ALL_FINDINGS = os.environ.get("SHOW_ALL_FINDINGS", "false").lower() == "true"
REQUESTED_PATHS = [Path(arg).resolve() for arg in sys.argv[1:] if arg]

RED = "\033[0;31m"
GREEN = "\033[0;32m"
YELLOW = "\033[1;33m"
CYAN = "\033[0;36m"
BOLD = "\033[1m"
NC = "\033[0m"

SCAN_ROOT = ROOT_DIR
_TEMP_SCAN_DIR = None

TRIVY_VULN_FILENAMES = {
    "requirements.txt",
    "poetry.lock",
    "pyproject.toml",
    "pipfile",
    "pipfile.lock",
    "package.json",
    "package-lock.json",
    "yarn.lock",
    "pnpm-lock.yaml",
    "go.mod",
    "go.sum",
    "pom.xml",
    "build.gradle",
    "build.gradle.kts",
    "gradle.lockfile",
    "composer.json",
    "composer.lock",
    "gemfile",
    "gemfile.lock",
    "cargo.toml",
    "cargo.lock",
}

TRIVY_IAC_FILENAMES = {
    "dockerfile",
    "docker-compose.yml",
    "docker-compose.yaml",
}

TRIVY_IAC_SUFFIXES = {".tf", ".yaml", ".yml", ".json"}


def run_command(args, cwd=ROOT_DIR):
    return subprocess.run(args, cwd=cwd, capture_output=True, text=True)


def with_trivy_skip_dirs(args):
    full_args = list(args)
    for directory in SCAN_SKIP_DIRS:
        full_args.extend(["--skip-dirs", directory])
    return full_args


def with_semgrep_excludes(args):
    full_args = list(args)
    for directory in SCAN_SKIP_DIRS:
        full_args.extend(["--exclude", directory])
    return full_args


def resolve_binary(explicit_path, fallback_name):
    if explicit_path.exists():
        return str(explicit_path)
    return shutil.which(fallback_name)


def shorten(text, limit=120):
    text = " ".join(str(text).split())
    if len(text) <= limit:
        return text
    return text[: limit - 3] + "..."


def format_path(path_value):
    if not path_value:
        return "unknown"
    try:
        path = Path(path_value)
        for base in (SCAN_ROOT, ROOT_DIR):
            try:
                return str(path.relative_to(base))
            except Exception:
                continue
    except Exception:
        pass
    return str(path_value)


def should_skip_path(path: Path) -> bool:
    parts = set(path.parts)
    return any(skip_dir in parts for skip_dir in SCAN_SKIP_DIRS)


def prepare_scan_root():
    global SCAN_ROOT, _TEMP_SCAN_DIR

    selected_paths = []
    for path in REQUESTED_PATHS:
        try:
            relative = path.relative_to(ROOT_DIR)
        except ValueError:
            continue
        if should_skip_path(relative):
            continue
        if path.exists():
            selected_paths.append(relative)

    if not selected_paths:
        SCAN_ROOT = ROOT_DIR
        return

    _TEMP_SCAN_DIR = tempfile.TemporaryDirectory(prefix="precommit-scan-")
    temp_root = Path(_TEMP_SCAN_DIR.name)

    for relative_path in selected_paths:
        source = ROOT_DIR / relative_path
        destination = temp_root / relative_path
        destination.parent.mkdir(parents=True, exist_ok=True)
        if source.is_dir():
            shutil.copytree(source, destination, dirs_exist_ok=True)
        else:
            shutil.copy2(source, destination)

    SCAN_ROOT = temp_root


def selected_relative_paths():
    if not REQUESTED_PATHS:
        return []
    selected = []
    for path in REQUESTED_PATHS:
        try:
            relative = path.relative_to(ROOT_DIR)
        except ValueError:
            continue
        if should_skip_path(relative):
            continue
        selected.append(relative)
    return selected


def has_selected_paths():
    return len(selected_relative_paths()) > 0


def trivy_vuln_applicable():
    if not has_selected_paths():
        return True

    for relative in selected_relative_paths():
        name = relative.name.lower()
        if name in TRIVY_VULN_FILENAMES:
            return True
    return False


def trivy_iac_applicable():
    if not has_selected_paths():
        return True

    for relative in selected_relative_paths():
        name = relative.name.lower()
        suffix = relative.suffix.lower()
        if name in TRIVY_IAC_FILENAMES:
            return True
        if suffix in TRIVY_IAC_SUFFIXES:
            return True
    return False


def cleanup_scan_root():
    global _TEMP_SCAN_DIR
    if _TEMP_SCAN_DIR is not None:
        _TEMP_SCAN_DIR.cleanup()
        _TEMP_SCAN_DIR = None


def count_severities(value, counter):
    if isinstance(value, dict):
        severity = value.get("Severity")
        if severity in {"CRITICAL", "HIGH", "MEDIUM", "LOW"}:
            counter[severity] += 1
        for child in value.values():
            count_severities(child, counter)
    elif isinstance(value, list):
        for item in value:
            count_severities(item, counter)


def count_semgrep_severities(payload):
    counter = Counter({"ERROR": 0, "WARNING": 0, "INFO": 0})
    for result in payload.get("results", []):
        severity = (result.get("extra", {}) or {}).get("severity")
        if severity in counter:
            counter[severity] += 1
    return counter


def findings_limit():
    return None if SHOW_ALL_FINDINGS else 3


def gitleaks_status():
    if not ENABLE_GITLEAKS:
        return "SKIPPED", "disabled", None, []
    if not shutil.which("gitleaks"):
        return "SKIPPED", "not installed", None, []

    with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as tmp:
        report_path = tmp.name
    try:
        result = run_command(
            ["gitleaks", "detect", "--source", ".", "--no-git", "--report-format", "json", "--report-path", report_path],
            cwd=SCAN_ROOT,
        )
        leaks = []
        if os.path.exists(report_path) and os.path.getsize(report_path) > 0:
            with open(report_path, "r", encoding="utf-8") as fh:
                leaks = json.load(fh)
        count = len(leaks)
        if result.returncode == 0 and count == 0:
            return "PASSED", "0 secrets", None, []

        findings = []
        leak_slice = leaks if findings_limit() is None else leaks[: findings_limit()]
        for leak in leak_slice:
            finding = leak.get("File", "unknown")
            line = leak.get("StartLine") or leak.get("Line") or "?"
            rule = leak.get("RuleID", "secret")
            findings.append(f"{format_path(finding)}:{line} - {rule}")

        return "FAILED", f"{count} secrets found", f"Gitleaks Secret Detection: FAILED ({count} secrets found)", findings
    finally:
        if os.path.exists(report_path):
            os.unlink(report_path)


def trivy_status(args, label):
    if not ENABLE_TRIVY:
        return "SKIPPED", "disabled", None, []
    if not shutil.which("trivy"):
        return "SKIPPED", "not installed", None, []
    if label == "Trivy Vulnerability Scan" and not trivy_vuln_applicable():
        return "SKIPPED", "not applicable", None, []
    if label == "Trivy IaC Scan" and not trivy_iac_applicable():
        return "SKIPPED", "not applicable", None, []
    result = run_command(with_trivy_skip_dirs(args), cwd=SCAN_ROOT)
    try:
        payload = json.loads(result.stdout or "{}")
    except json.JSONDecodeError:
        return "FAILED", "scanner error", f"{label}: FAILED (scanner error)", [shorten(result.stderr or "JSON parse error")]
    counter = Counter({"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0})
    count_severities(payload, counter)
    details = f"{counter['CRITICAL']} CRIT, {counter['HIGH']} HIGH, {counter['MEDIUM']} MED, {counter['LOW']} LOW"
    findings = []
    result_items = payload.get("Results", [])

    limit = findings_limit()
    for result_item in result_items:
        target = format_path(result_item.get("Target", "unknown"))
        for vuln in (result_item.get("Vulnerabilities") or []):
            findings.append(
                f"{target} - {vuln.get('PkgName', 'pkg')} {vuln.get('InstalledVersion', '?')} - {vuln.get('VulnerabilityID', '?')} ({vuln.get('Severity', '?')})"
            )
            if limit is not None and len(findings) >= limit:
                break
        if limit is not None and len(findings) >= limit:
            break

    if limit is None or len(findings) < limit:
        for result_item in result_items:
            target = format_path(result_item.get("Target", "unknown"))
            for misconf in (result_item.get("Misconfigurations") or []):
                findings.append(
                    f"{target} - {misconf.get('ID', '?')} ({misconf.get('Severity', '?')}) - {shorten(misconf.get('Title', ''))}"
                )
                if limit is not None and len(findings) >= limit:
                    break
            if limit is not None and len(findings) >= limit:
                break

    if not findings and result.stderr.strip():
        findings.append(shorten(result.stderr.strip()))

    if counter["CRITICAL"] > 0 or counter["HIGH"] > 0:
        return "FAILED", details, f"{label}: FAILED ({details})", findings
    return "PASSED", details, None, []


def semgrep_status():
    if not ENABLE_SEMGREP:
        return "SKIPPED", "disabled", None, []
    semgrep_bin = resolve_binary(SEMGREP_BIN, "semgrep")
    if not semgrep_bin:
        return "SKIPPED", "not installed", None, []
    result = run_command(
        with_semgrep_excludes([semgrep_bin, "scan", f"--config={SEMGREP_RULESET}", "--json", "."]),
        cwd=SCAN_ROOT,
    )
    try:
        payload = json.loads(result.stdout or "{}")
    except json.JSONDecodeError:
        return "FAILED", "scanner error", "Semgrep Security Scan: FAILED (scanner error)", [shorten(result.stderr or "JSON parse error")]
    counter = count_semgrep_severities(payload)
    details = f"{counter['ERROR']} ERROR, {counter['WARNING']} WARNING, {counter['INFO']} INFO"
    findings = []
    results = payload.get("results", [])
    result_slice = results if findings_limit() is None else results[: findings_limit()]
    for result_item in result_slice:
        path = format_path(result_item.get("path", "unknown"))
        start = (result_item.get("start") or {}).get("line", "?")
        rule = result_item.get("check_id", "rule")
        message = shorten((result_item.get("extra") or {}).get("message", ""))
        severity = (result_item.get("extra") or {}).get("severity", "?")
        findings.append(f"{path}:{start} - {rule} ({severity}) - {message}")
    if counter["ERROR"] > 0:
        return "FAILED", details, f"Semgrep Security Scan: FAILED ({details})", findings
    return "PASSED", details, None, []


def gosec_status():
    if not ENABLE_GOSEC:
        return "SKIPPED", "disabled", None, []
    if not shutil.which("gosec"):
        return "SKIPPED", "not installed", None, []
    result = run_command(["gosec", "-fmt", "json", "./..."], cwd=SCAN_ROOT)
    try:
        payload = json.loads(result.stdout or "{}")
    except json.JSONDecodeError:
        payload = {}
    issues = len(payload.get("Issues", []) or [])
    findings = []
    issues_list = payload.get("Issues", []) or []
    issue_slice = issues_list if findings_limit() is None else issues_list[: findings_limit()]
    for issue in issue_slice:
        findings.append(
            f"{format_path(issue.get('file', 'unknown'))}:{issue.get('line', '?')} - {issue.get('rule_id', '?')} ({issue.get('severity', '?')})"
        )
    if issues > 0:
        return "FAILED", f"{issues} issues", f"GoSec Security Scan: FAILED ({issues} issues)", findings
    return "PASSED", "0 issues", None, []


def mobsfscan_status():
    if not ENABLE_MOBSFSCAN:
        return "SKIPPED", "disabled", None, []
    if not MOBSFSCAN_BIN.exists():
        return "SKIPPED", "not installed", None, []
    result = run_command([str(MOBSFSCAN_BIN), "--json", "."], cwd=SCAN_ROOT)
    try:
        payload = json.loads(result.stdout or "[]")
    except json.JSONDecodeError:
        return "FAILED", "scanner error", "MobSF Mobile Security Scan: FAILED (scanner error)", [shorten(result.stderr or "JSON parse error")]
    if isinstance(payload, list):
        issues = len(payload)
        iterable = payload
    else:
        issues = len(payload.get("results", []))
        iterable = payload.get("results", [])
    findings = []
    iterable_slice = iterable if findings_limit() is None else iterable[: findings_limit()]
    for issue in iterable_slice:
        findings.append(
            f"{format_path(issue.get('filename', issue.get('path', 'unknown')))} - {issue.get('rule', issue.get('test_id', '?'))} ({issue.get('severity', '?')})"
        )
    if issues > 0:
        return "FAILED", f"{issues} issues", f"MobSF Mobile Security Scan: FAILED ({issues} issues)", findings
    return "PASSED", "0 issues", None, []


def colored(status, details):
    color = {"PASSED": GREEN, "FAILED": RED, "SKIPPED": YELLOW}[status]
    return f"{color}{status} ({details}){NC}"


def build_follow_up_commands():
    requested = [str(path) for path in REQUESTED_PATHS if path.exists()]
    file_args = " ".join(format_path(path) for path in requested)
    commands = []

    if requested:
        commands.append(f"SHOW_ALL_FINDINGS=true pre-commit run --files {file_args}")
    else:
        commands.append("SHOW_ALL_FINDINGS=true pre-commit run --all-files")

    return commands


def main():
    prepare_scan_root()
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    committer = run_command(["git", "config", "user.name"]).stdout.strip() or "Unknown"
    branch = run_command(["git", "rev-parse", "--abbrev-ref", "HEAD"]).stdout.strip() or "Unknown"

    checks = [
        ("✓ Gitleaks Secret Detection", gitleaks_status()),
        ("✓ Trivy Vulnerability Scan", trivy_status(["trivy", "fs", "--scanners", "vuln", "--severity", "CRITICAL,HIGH,MEDIUM,LOW", "--format", "json", "."], "Trivy Vulnerability Scan")),
        ("✓ Trivy IaC Scan", trivy_status(["trivy", "fs", "--scanners", "misconfig", "--severity", "CRITICAL,HIGH,MEDIUM,LOW", "--format", "json", "."], "Trivy IaC Scan")),
        ("✓ Semgrep Security Scan", semgrep_status()),
        ("○ GoSec Security Scan", gosec_status()),
        ("○ MobSF Mobile Security Scan", mobsfscan_status()),
    ]

    passed = failed = skipped = 0
    failed_hooks = []
    detailed_findings = []
    for label, (status, _, hook, findings) in checks:
        if status == "PASSED":
            passed += 1
        elif status == "FAILED":
            failed += 1
            if hook:
                failed_hooks.append(hook)
            if findings:
                detailed_findings.append((label, findings))
        else:
            skipped += 1

    width = 65
    divider = "═" * width
    thin = "─" * width

    print()
    print(f"{CYAN}{BOLD}{divider}{NC}")
    print(f"{CYAN}{BOLD}{'SECURITY SCAN SUMMARY':^{width}}{NC}")
    print(f"{CYAN}{BOLD}{divider}{NC}")
    print()
    print(f"  {BOLD}Thời gian :{NC} {timestamp}")
    print(f"  {BOLD}Developer :{NC} {committer}")
    print(f"  {BOLD}Branch    :{NC} {branch}")
    print()
    print(f"  {thin}")
    print()
    for label, (status, details, _, _) in checks:
        print(f"  {label:<35} {colored(status, details)}")
    print()
    print(f"  {thin}")
    print()

    if failed == 0:
        print(f"  {GREEN}{BOLD}RESULT: PASSED ({passed} passed, {skipped} skipped){NC}")
        print()
        cleanup_scan_root()
        return 0

    print(f"  {RED}{BOLD}RESULT: FAILED ({failed} failed, {passed} passed, {skipped} skipped){NC}")
    print()
    print(f"  {RED}{BOLD}Failed hooks:{NC}")
    for hook in failed_hooks:
        print(f"  {RED}- {hook}{NC}")
    print()
    if detailed_findings:
        print(f"  {YELLOW}{BOLD}Chi tiết nổi bật:{NC}")
        for label, findings in detailed_findings:
            print(f"  {YELLOW}{label}:{NC}")
            for finding in findings:
                print(f"    - {finding}")
        print()

    print(f"  {CYAN}{BOLD}Xem đầy đủ:{NC}")
    for command in build_follow_up_commands():
        print(f"  {CYAN}- {command}{NC}")
    print()
    cleanup_scan_root()
    return 1


if __name__ == "__main__":
    sys.exit(main())
